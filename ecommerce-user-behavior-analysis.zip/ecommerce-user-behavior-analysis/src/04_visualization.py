# -*- coding: utf-8 -*-
"""
模块4：PyEcharts数据可视化
功能：
1. 用户行为分布饼图
2. 用户行为分布柱状图
3. 31个省份统计柱状图
4. 用户活跃时段折线图
5. 每日趋势折线图
6. 生成HTML可视化报告
"""
import os
import sys
import pandas as pd
from pyecharts import options as opts
from pyecharts.charts import Pie, Bar, Line, Page
from pyecharts.globals import ThemeType

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import OUTPUT_DIR


def load_data():
    """加载分析结果数据"""
    print('[1/6] 正在加载分析结果数据...')
    behavior_df = pd.read_csv(os.path.join(OUTPUT_DIR, 'behavior_distribution.csv'))
    province_df = pd.read_csv(os.path.join(OUTPUT_DIR, 'province_statistics.csv'))
    daily_df = pd.read_csv(os.path.join(OUTPUT_DIR, 'daily_statistics.csv'))
    hourly_df = pd.read_csv(os.path.join(OUTPUT_DIR, 'hourly_statistics.csv'))
    print(f'  行为分布数据: {len(behavior_df)} 条')
    print(f'  省份统计数据: {len(province_df)} 条')
    print(f'  每日统计数据: {len(daily_df)} 条')
    print(f'  每小时统计数据: {len(hourly_df)} 条')
    return behavior_df, province_df, daily_df, hourly_df


def create_behavior_pie(behavior_df):
    """创建用户行为分布饼图"""
    print('\n[2/6] 创建用户行为分布饼图...')
    data_pair = [(row['behavior_type'], int(row['behavior_count']))
                 for _, row in behavior_df.iterrows()]
    pie = (
        Pie(init_opts=opts.InitOpts(width='800px', height='500px', theme=ThemeType.LIGHT))
        .add(series_name='用户行为', data_pair=data_pair, radius=['40%', '70%'],
             label_opts=opts.LabelOpts(formatter='{b}: {d}%'))
        .set_global_opts(
            title_opts=opts.TitleOpts(title='电商用户行为分布', subtitle='浏览/收藏/加购/购买占比'),
            legend_opts=opts.LegendOpts(orient='vertical', pos_left='left'),
            tooltip_opts=opts.TooltipOpts(trigger='item', formatter='{a}<br/>{b}: {c} ({d}%)'))
    )
    return pie


def create_behavior_bar(behavior_df):
    """创建用户行为分布柱状图"""
    print('[3/6] 创建用户行为分布柱状图...')
    x_data = behavior_df['behavior_type'].tolist()
    y_data = behavior_df['behavior_count'].astype(int).tolist()
    bar = (
        Bar(init_opts=opts.InitOpts(width='800px', height='500px', theme=ThemeType.LIGHT))
        .add_xaxis(x_data)
        .add_yaxis('行为次数', y_data, category_gap='50%')
        .set_global_opts(
            title_opts=opts.TitleOpts(title='电商用户行为次数统计', subtitle='各行为类型绝对数量'),
            xaxis_opts=opts.AxisOpts(name='行为类型'),
            yaxis_opts=opts.AxisOpts(name='行为次数'),
            tooltip_opts=opts.TooltipOpts(trigger='axis', axis_pointer_type='shadow'))
        .set_series_opts(label_opts=opts.LabelOpts(position='top'))
    )
    return bar


def create_province_bar(province_df):
    """创建31个省份统计柱状图"""
    print('[4/6] 创建省份统计柱状图...')
    top_provinces = province_df.head(15)
    x_data = top_provinces['province'].tolist()
    y_data = top_provinces['total_behavior'].astype(int).tolist()
    bar = (
        Bar(init_opts=opts.InitOpts(width='1000px', height='500px', theme=ThemeType.LIGHT))
        .add_xaxis(x_data)
        .add_yaxis('行为总数', y_data, category_gap='30%')
        .set_global_opts(
            title_opts=opts.TitleOpts(title='各省份用户行为统计 Top15', subtitle='按行为总数排序'),
            xaxis_opts=opts.AxisOpts(name='省份', axislabel_opts=opts.LabelOpts(rotate=45)),
            yaxis_opts=opts.AxisOpts(name='行为次数'),
            tooltip_opts=opts.TooltipOpts(trigger='axis', axis_pointer_type='shadow'),
            datazoom_opts=[opts.DataZoomOpts()])
        .set_series_opts(label_opts=opts.LabelOpts(position='top'))
    )
    return bar


def create_hourly_line(hourly_df):
    """创建用户活跃时段折线图"""
    print('[5/6] 创建用户活跃时段折线图...')
    x_data = [f'{int(h)}时' for h in hourly_df['hour'].tolist()]
    y_data = hourly_df['total_behavior'].astype(int).tolist()
    line = (
        Line(init_opts=opts.InitOpts(width='900px', height='500px', theme=ThemeType.LIGHT))
        .add_xaxis(x_data)
        .add_yaxis('行为次数', y_data, is_smooth=True,
                   markpoint_opts=opts.MarkPointOpts(data=[
                       opts.MarkPointItem(type_='max', name='峰值'),
                       opts.MarkPointItem(type_='min', name='谷值')]))
        .set_global_opts(
            title_opts=opts.TitleOpts(title='用户活跃时段分布', subtitle='按小时统计用户行为数'),
            xaxis_opts=opts.AxisOpts(name='时段'),
            yaxis_opts=opts.AxisOpts(name='行为次数'),
            tooltip_opts=opts.TooltipOpts(trigger='axis'))
    )
    return line


def create_daily_line(daily_df):
    """创建每日趋势折线图"""
    print('[6/6] 创建每日趋势折线图...')
    x_data = daily_df['date'].tolist()
    y_behavior = daily_df['total_behavior'].astype(int).tolist()
    y_users = daily_df['active_users'].astype(int).tolist()
    line = (
        Line(init_opts=opts.InitOpts(width='900px', height='500px', theme=ThemeType.LIGHT))
        .add_xaxis(x_data)
        .add_yaxis('行为总数', y_behavior, is_smooth=True)
        .add_yaxis('活跃用户数', y_users, is_smooth=True, yaxis_index=1)
        .extend_axis(yaxis=opts.AxisOpts(name='活跃用户数', position='right'))
        .set_global_opts(
            title_opts=opts.TitleOpts(title='每日用户行为趋势', subtitle='行为总数与活跃用户数'),
            xaxis_opts=opts.AxisOpts(name='日期'),
            yaxis_opts=opts.AxisOpts(name='行为次数', position='left'),
            tooltip_opts=opts.TooltipOpts(trigger='axis'),
            legend_opts=opts.LegendOpts(pos_top='5%'))
    )
    return line


def main():
    """主函数"""
    print('=' * 60)
    print('电商用户行为数据 - PyEcharts数据可视化')
    print('=' * 60)

    behavior_df, province_df, daily_df, hourly_df = load_data()
    pie = create_behavior_pie(behavior_df)
    bar_behavior = create_behavior_bar(behavior_df)
    bar_province = create_province_bar(province_df)
    line_hourly = create_hourly_line(hourly_df)
    line_daily = create_daily_line(daily_df)

    page = Page(page_title='电商用户行为分析可视化报告')
    page.add(pie, bar_behavior, bar_province, line_hourly, line_daily)

    output_html = os.path.join(OUTPUT_DIR, 'visualization_report.html')
    page.render(output_html)
    pie.render(os.path.join(OUTPUT_DIR, '01_behavior_pie.html'))
    bar_behavior.render(os.path.join(OUTPUT_DIR, '02_behavior_bar.html'))
    bar_province.render(os.path.join(OUTPUT_DIR, '03_province_bar.html'))
    line_hourly.render(os.path.join(OUTPUT_DIR, '04_hourly_line.html'))
    line_daily.render(os.path.join(OUTPUT_DIR, '05_daily_line.html'))

    print('\n' + '=' * 60)
    print('数据可视化完成！')
    print('=' * 60)
    print(f'  可视化报告: {output_html}')


if __name__ == '__main__':
    main()
