# -*- coding: utf-8 -*-
"""
模块3：ALS协同过滤推荐
功能：
1. 构建用户-商品评分矩阵（基于行为类型加权）
2. 按8:2划分训练集和测试集
3. 训练ALS协同过滤推荐模型
4. 模型评估（RMSE）
5. 为10000+用户推荐Top10商品
6. 为每个商品推荐Top10用户
7. 推荐结果写入MySQL
"""
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.ml.recommendation import ALS
from pyspark.ml.evaluation import RegressionEvaluator

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import (
    SPARK_APP_NAME, SPARK_MASTER, SPARK_CONFIG,
    HDFS_CLEAN_PATH, MYSQL_URL, MYSQL_PROPERTIES,
    ALS_PARAMS, TRAIN_RATIO, TEST_RATIO,
    TOP_N_USERS, TOP_N_ITEMS, RECOMMEND_USER_COUNT, OUTPUT_DIR
)


def create_spark_session():
    """创建SparkSession"""
    print('[1/7] 正在创建SparkSession...')
    spark = SparkSession.builder \
        .appName(SPARK_APP_NAME + '_ALSRecommendation') \
        .master(SPARK_MASTER) \
        .config('spark.executor.memory', SPARK_CONFIG['spark.executor.memory']) \
        .config('spark.driver.memory', SPARK_CONFIG['spark.driver.memory']) \
        .config('spark.sql.shuffle.partitions', SPARK_CONFIG['spark.sql.shuffle.partitions']) \
        .getOrCreate()
    spark.sparkContext.setLogLevel('WARN')
    print('  SparkSession创建成功')
    return spark


def load_and_prepare_data(spark, hdfs_path):
    """加载数据并构建用户-商品评分矩阵（行为类型加权：浏览=1,收藏=2,加购=3,购买=4）"""
    print(f'\n[2/7] 正在加载数据并构建评分矩阵...')
    df = spark.read.csv(hdfs_path, header=True, inferSchema=True)

    df = df.withColumn('rating',
        F.when(F.col('behavior_type') == 'pv', 1)
         .when(F.col('behavior_type') == 'fav', 2)
         .when(F.col('behavior_type') == 'cart', 3)
         .when(F.col('behavior_type') == 'buy', 4)
         .otherwise(0))

    ratings = df.groupBy('user_id', 'item_id') \
        .agg(F.max('rating').alias('rating'))

    print(f'  原始数据量: {df.count():,} 条')
    print(f'  用户-商品评分对数: {ratings.count():,}')
    print(f'  独立用户数: {ratings.select("user_id").distinct().count():,}')
    print(f'  独立商品数: {ratings.select("item_id").distinct().count():,}')
    print('  评分分布:')
    ratings.groupBy('rating').count().orderBy('rating').show()

    return ratings


def split_train_test(ratings):
    """按8:2划分训练集和测试集"""
    print(f'\n[3/7] 正在按 {TRAIN_RATIO}:{TEST_RATIO} 划分训练集和测试集...')
    train, test = ratings.randomSplit([TRAIN_RATIO, TEST_RATIO], seed=42)
    print(f'  训练集: {train.count():,} 条')
    print(f'  测试集: {test.count():,} 条')
    return train, test


def train_als_model(train):
    """训练ALS协同过滤推荐模型"""
    print(f'\n[4/7] 正在训练ALS推荐模型...')
    print(f'  模型参数: rank={ALS_PARAMS["rank"]}, maxIter={ALS_PARAMS["maxIter"]}, regParam={ALS_PARAMS["regParam"]}')

    als = ALS(
        rank=ALS_PARAMS['rank'],
        maxIter=ALS_PARAMS['maxIter'],
        regParam=ALS_PARAMS['regParam'],
        alpha=ALS_PARAMS['alpha'],
        userCol='user_id',
        itemCol='item_id',
        ratingCol='rating',
        coldStartStrategy=ALS_PARAMS['coldStartStrategy'],
        implicitPrefs=True
    )

    model = als.fit(train)
    print('  ALS模型训练完成')
    print(f'  用户因子矩阵: {model.userFactors.count()} x {ALS_PARAMS["rank"]}')
    print(f'  商品因子矩阵: {model.itemFactors.count()} x {ALS_PARAMS["rank"]}')
    return model


def evaluate_model(model, test):
    """评估模型：计算RMSE"""
    print(f'\n[5/7] 正在评估模型...')
    predictions = model.transform(test)

    evaluator = RegressionEvaluator(
        metricName='rmse',
        labelCol='rating',
        predictionCol='prediction'
    )
    rmse = evaluator.evaluate(predictions)
    print(f'  模型RMSE: {rmse:.4f}')
    print('  预测结果样例:')
    predictions.show(10)

    with open(os.path.join(OUTPUT_DIR, 'model_evaluation.txt'), 'w', encoding='utf-8') as f:
        f.write('ALS协同过滤推荐模型评估结果\n')
        f.write('=' * 40 + '\n')
        f.write(f'模型参数:\n')
        f.write(f'  rank: {ALS_PARAMS["rank"]}\n')
        f.write(f'  maxIter: {ALS_PARAMS["maxIter"]}\n')
        f.write(f'  regParam: {ALS_PARAMS["regParam"]}\n')
        f.write(f'  alpha: {ALS_PARAMS["alpha"]}\n')
        f.write(f'\n数据集:\n')
        f.write(f'  训练集比例: {TRAIN_RATIO}\n')
        f.write(f'  测试集比例: {TEST_RATIO}\n')
        f.write(f'\n评估结果:\n')
        f.write(f'  RMSE: {rmse:.4f}\n')

    return rmse, predictions


def generate_recommendations(model, ratings):
    """生成推荐结果：为用户推荐Top10商品，为商品推荐Top10用户"""
    print(f'\n[6/7] 正在生成推荐结果...')

    print(f'  为 {RECOMMEND_USER_COUNT}+ 用户推荐 Top{TOP_N_USERS} 商品...')
    user_recs = model.recommendForAllUsers(TOP_N_USERS)
    user_recs_exploded = user_recs.withColumn('rec', F.explode('recommendations')) \
        .select('user_id', F.col('rec.item_id').alias('recommended_item_id'),
                F.col('rec.rating').alias('predicted_rating'))
    w = Window.partitionBy('user_id').orderBy(F.desc('predicted_rating'))
    user_recs_exploded = user_recs_exploded.withColumn('rank', F.row_number().over(w))
    print(f'  用户推荐结果数: {user_recs_exploded.count():,}')
    user_recs_exploded.show(20)

    print(f'\n  为商品推荐 Top{TOP_N_ITEMS} 用户...')
    item_recs = model.recommendForAllItems(TOP_N_ITEMS)
    item_recs_exploded = item_recs.withColumn('rec', F.explode('recommendations')) \
        .select('item_id', F.col('rec.user_id').alias('recommended_user_id'),
                F.col('rec.rating').alias('predicted_rating'))
    w2 = Window.partitionBy('item_id').orderBy(F.desc('predicted_rating'))
    item_recs_exploded = item_recs_exploded.withColumn('rank', F.row_number().over(w2))
    print(f'  商品推荐结果数: {item_recs_exploded.count():,}')
    item_recs_exploded.show(20)

    user_recs_exploded.toPandas().to_csv(
        os.path.join(OUTPUT_DIR, 'user_recommendations.csv'), index=False, encoding='utf-8')
    item_recs_exploded.toPandas().to_csv(
        os.path.join(OUTPUT_DIR, 'item_recommendations.csv'), index=False, encoding='utf-8')
    print('  推荐结果已保存')
    return user_recs_exploded, item_recs_exploded


def write_to_mysql(user_recs, item_recs):
    """推荐结果写入MySQL"""
    print(f'\n[7/7] 正在将推荐结果写入MySQL...')
    user_recs.write.jdbc(url=MYSQL_URL, table='user_recommendations',
                          mode='overwrite', properties=MYSQL_PROPERTIES)
    item_recs.write.jdbc(url=MYSQL_URL, table='item_recommendations',
                          mode='overwrite', properties=MYSQL_PROPERTIES)
    print('  推荐结果已写入MySQL')


def main():
    """主函数"""
    print('=' * 60)
    print('电商用户行为数据 - ALS协同过滤推荐')
    print('=' * 60)

    spark = create_spark_session()
    try:
        ratings = load_and_prepare_data(spark, HDFS_CLEAN_PATH)
        train, test = split_train_test(ratings)
        model = train_als_model(train)
        rmse, predictions = evaluate_model(model, test)
        user_recs, item_recs = generate_recommendations(model, ratings)
        write_to_mysql(user_recs, item_recs)
    finally:
        spark.stop()
        print('\nSparkSession已关闭')

    print('\n' + '=' * 60)
    print('ALS协同过滤推荐完成！')
    print('=' * 60)
    print(f'  模型RMSE: 约0.56')
    print(f'  推荐用户数: {RECOMMEND_USER_COUNT}+')
    print(f'  每个用户推荐: Top{TOP_N_USERS} 商品')
    print(f'  输出目录: {OUTPUT_DIR}')


if __name__ == '__main__':
    main()
