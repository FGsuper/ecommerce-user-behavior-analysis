# -*- coding: utf-8 -*-
"""
模块1：数据预处理与ETL
功能：
1. 读取500万+条CSV原始数据
2. 统计各字段缺失值与数据质量
3. 删除空白值过多的user_geohash字段
4. 新增province维度字段
5. 时间戳转换
6. 清洗后数据保存并上传HDFS
"""
import os
import sys
import pandas as pd
import numpy as np

# 添加项目根目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import RAW_DATA_PATH, CLEAN_DATA_PATH, HDFS_CLEAN_PATH, DATA_COLUMNS


def load_raw_data(file_path):
    """
    读取原始CSV数据
    :param file_path: 原始数据路径
    :return: DataFrame
    """
    print(f'[1/6] 正在读取原始数据: {file_path}')
    df = pd.read_csv(file_path, header=None, names=DATA_COLUMNS, dtype={
        'user_id': 'int32',
        'item_id': 'int32',
        'category_id': 'int32',
        'behavior_type': 'category',
        'timestamp': 'int64',
        'user_geohash': 'str'
    })
    print(f'  数据量: {len(df):,} 条')
    print(f'  内存占用: {df.memory_usage(deep=True).sum() / 1024 / 1024:.2f} MB')
    return df


def check_data_quality(df):
    """
    检查数据质量：缺失值、重复值、异常值
    :param df: 原始DataFrame
    :return: 数据质量报告
    """
    print('\n[2/6] 正在检查数据质量...')
    
    quality_report = {}
    
    # 缺失值统计
    print('  --- 缺失值统计 ---')
    missing = df.isnull().sum()
    missing_pct = (missing / len(df) * 100).round(2)
    for col in df.columns:
        if missing[col] > 0:
            print(f'    {col}: {missing[col]:,} 缺失 ({missing_pct[col]}%)')
    quality_report['missing'] = missing.to_dict()
    
    # 重复值统计
    duplicate_count = df.duplicated().sum()
    print(f'\n  重复记录数: {duplicate_count:,} ({duplicate_count/len(df)*100:.2f}%)')
    quality_report['duplicates'] = duplicate_count
    
    # 行为类型分布
    print('\n  --- 行为类型分布 ---')
    behavior_dist = df['behavior_type'].value_counts()
    for behavior, count in behavior_dist.items():
        print(f'    {behavior}: {count:,} ({count/len(df)*100:.2f}%)')
    quality_report['behavior_dist'] = behavior_dist.to_dict()
    
    # 用户数和商品数
    user_count = df['user_id'].nunique()
    item_count = df['item_id'].nunique()
    print(f'\n  独立用户数: {user_count:,}')
    print(f'  独立商品数: {item_count:,}')
    quality_report['user_count'] = user_count
    quality_report['item_count'] = item_count
    
    return quality_report


def clean_data(df):
    """
    数据清洗：
    1. 删除user_geohash字段（缺失值过多）
    2. 删除重复记录
    3. 新增province维度字段
    4. 时间戳转换为日期时间
    :param df: 原始DataFrame
    :return: 清洗后的DataFrame
    """
    print('\n[3/6] 正在进行数据清洗...')
    
    df_clean = df.copy()
    
    # 1. 删除user_geohash字段（缺失值超过90%，无分析价值）
    if 'user_geohash' in df_clean.columns:
        missing_pct = df_clean['user_geohash'].isnull().sum() / len(df_clean) * 100
        print(f'  删除 user_geohash 字段 (缺失率: {missing_pct:.1f}%)')
        df_clean = df_clean.drop('user_geohash', axis=1)
    
    # 2. 删除重复记录
    before_count = len(df_clean)
    df_clean = df_clean.drop_duplicates()
    after_count = len(df_clean)
    print(f'  删除重复记录: {before_count - after_count:,} 条 (剩余 {after_count:,} 条)')
    
    # 3. 新增province维度字段（模拟从geohash解析省份）
    # 实际项目中可通过geohash解码获取经纬度，再逆地理编码获取省份
    np.random.seed(42)
    provinces = ['广东', '浙江', '江苏', '北京', '上海', '山东', '四川', '湖北', 
                 '福建', '湖南', '河南', '河北', '安徽', '辽宁', '陕西', '江西', 
                 '重庆', '广西', '云南', '山西', '贵州', '黑龙江', '吉林', '甘肃', 
                 '内蒙古', '新疆', '海南', '宁夏', '青海', '西藏']
    df_clean['province'] = np.random.choice(provinces, size=len(df_clean), 
                                               p=[0.15, 0.12, 0.10, 0.09, 0.08, 0.07, 0.06, 0.05,
                                                  0.04, 0.04, 0.03, 0.03, 0.02, 0.02, 0.02, 0.02,
                                                  0.015, 0.015, 0.01, 0.01, 0.01, 0.008, 0.008, 0.005,
                                                  0.005, 0.003, 0.003, 0.002, 0.002, 0.001])
    print(f'  新增 province 维度字段 (覆盖 {df_clean["province"].nunique()} 个省份)')
    
    # 4. 时间戳转换为日期时间
    df_clean['datetime'] = pd.to_datetime(df_clean['timestamp'], unit='s')
    df_clean['date'] = df_clean['datetime'].dt.date
    df_clean['hour'] = df_clean['datetime'].dt.hour
    print(f'  时间戳转换完成，时间范围: {df_clean["datetime"].min()} ~ {df_clean["datetime"].max()}')
    
    return df_clean


def save_clean_data(df_clean, output_path):
    """
    保存清洗后的数据
    :param df_clean: 清洗后的DataFrame
    :param output_path: 输出路径
    """
    print(f'\n[4/6] 正在保存清洗后数据: {output_path}')
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df_clean.to_csv(output_path, index=False, encoding='utf-8')
    file_size = os.path.getsize(output_path) / 1024 / 1024
    print(f'  保存完成，文件大小: {file_size:.2f} MB')


def upload_to_hdfs(local_path, hdfs_path):
    """
    上传数据到HDFS
    :param local_path: 本地文件路径
    :param hdfs_path: HDFS目标路径
    """
    print(f'\n[5/6] 正在上传数据到HDFS: {hdfs_path}')
    # 实际环境中使用hadoop fs -put命令
    # os.system(f'hadoop fs -mkdir -p {hdfs_path}')
    # os.system(f'hadoop fs -put {local_path} {hdfs_path}')
    print(f'  [模拟] 上传 {local_path} -> {hdfs_path}')
    print('  实际运行请取消注释hadoop命令')


def main():
    """主函数"""
    print('=' * 60)
    print('电商用户行为数据 - 数据预处理与ETL')
    print('=' * 60)
    
    # 1. 读取原始数据
    df = load_raw_data(RAW_DATA_PATH)
    
    # 2. 检查数据质量
    quality_report = check_data_quality(df)
    
    # 3. 数据清洗
    df_clean = clean_data(df)
    
    # 4. 保存清洗后数据
    save_clean_data(df_clean, CLEAN_DATA_PATH)
    
    # 5. 上传到HDFS
    upload_to_hdfs(CLEAN_DATA_PATH, HDFS_CLEAN_PATH)
    
    # 6. 输出总结
    print('\n' + '=' * 60)
    print('[6/6] 数据预处理完成！')
    print('=' * 60)
    print(f'  原始数据量: {len(df):,} 条')
    print(f'  清洗后数据量: {len(df_clean):,} 条')
    print(f'  独立用户数: {df_clean["user_id"].nunique():,}')
    print(f'  独立商品数: {df_clean["item_id"].nunique():,}')
    print(f'  覆盖省份数: {df_clean["province"].nunique()}')
    print(f'  清洗后数据: {CLEAN_DATA_PATH}')
    print(f'  HDFS路径: {HDFS_CLEAN_PATH}')


if __name__ == '__main__':
    main()
