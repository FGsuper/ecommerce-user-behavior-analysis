# -*- coding: utf-8 -*-
"""
模块2：Spark SQL多维度统计分析
功能：
1. 读取HDFS上的清洗后数据
2. 用户行为统计（浏览/收藏/加购/购买分布）
3. 31个省份维度统计分析
4. 商品类目统计分析
5. 时间维度统计分析（按天/按小时）
6. 用户活跃度分析
7. 结果写入MySQL
"""
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import (
    SPARK_APP_NAME, SPARK_MASTER, SPARK_CONFIG,
    HDFS_CLEAN_PATH, MYSQL_URL, MYSQL_PROPERTIES,
    BEHAVIOR_NAMES, OUTPUT_DIR
)


def create_spark_session():
    """创建SparkSession"""
    print('[1/7] 正在创建SparkSession...')
    spark = SparkSession.builder \
        .appName(SPARK_APP_NAME + '_SQLAnalysis') \
        .master(SPARK_MASTER) \
        .config('spark.executor.memory', SPARK_CONFIG['spark.executor.memory']) \
        .config('spark.driver.memory', SPARK_CONFIG['spark.driver.memory']) \
        .config('spark.sql.shuffle.partitions', SPARK_CONFIG['spark.sql.shuffle.partitions']) \
        .getOrCreate()
    spark.sparkContext.setLogLevel('WARN')
    print(f'  SparkSession创建成功: {spark.sparkContext.appName}')
    return spark


def load_data_from_hdfs(spark, hdfs_path):
    """从HDFS读取清洗后的数据"""
    print(f'\n[2/7] 正在从HDFS读取数据: {hdfs_path}')
    df = spark.read.csv(hdfs_path, header=True, inferSchema=True)
    print(f'  数据量: {df.count():,} 条')
    print(f'  字段: {df.columns}')
    df.createOrReplaceTempView('user_behavior')
    return df


def analyze_behavior_distribution(spark):
    """分析1：用户行为类型分布"""
    print('\n[3/7] 分析1：用户行为类型分布...')
    sql = """
        SELECT 
            behavior_type,
            COUNT(*) as behavior_count,
            ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2) as percentage
        FROM user_behavior
        GROUP BY behavior_type
        ORDER BY behavior_count DESC
    """
    result = spark.sql(sql)
    result.show()
    result = result.replace(BEHAVIOR_NAMES)
    result_pd = result.toPandas()
    result_pd.to_csv(os.path.join(OUTPUT_DIR, 'behavior_distribution.csv'), index=False, encoding='utf-8')
    print('  行为分布结果已保存')
    return result


def analyze_province_statistics(spark):
    """分析2：31个省份维度统计分析"""
    print('\n[4/7] 分析2：省份维度统计分析...')
    sql = """
        SELECT 
            province,
            COUNT(DISTINCT user_id) as user_count,
            COUNT(*) as total_behavior,
            SUM(CASE WHEN behavior_type = 'buy' THEN 1 ELSE 0 END) as buy_count,
            ROUND(SUM(CASE WHEN behavior_type = 'buy' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as buy_rate
        FROM user_behavior
        GROUP BY province
        ORDER BY total_behavior DESC
    """
    result = spark.sql(sql)
    result.show(31)
    print(f'  覆盖省份数: {result.count()}')
    result_pd = result.toPandas()
    result_pd.to_csv(os.path.join(OUTPUT_DIR, 'province_statistics.csv'), index=False, encoding='utf-8')
    print('  省份统计结果已保存')
    return result


def analyze_category_statistics(spark):
    """分析3：商品类目统计分析"""
    print('\n[5/7] 分析3：商品类目统计分析...')
    sql = """
        SELECT 
            category_id,
            COUNT(*) as behavior_count,
            COUNT(DISTINCT user_id) as user_count,
            COUNT(DISTINCT item_id) as item_count,
            SUM(CASE WHEN behavior_type = 'buy' THEN 1 ELSE 0 END) as buy_count
        FROM user_behavior
        GROUP BY category_id
        ORDER BY behavior_count DESC
        LIMIT 10
    """
    result = spark.sql(sql)
    result.show()
    result_pd = result.toPandas()
    result_pd.to_csv(os.path.join(OUTPUT_DIR, 'category_top10.csv'), index=False, encoding='utf-8')
    print('  类目Top10结果已保存')
    return result


def analyze_time_statistics(spark):
    """分析4：时间维度统计分析"""
    print('\n[6/7] 分析4：时间维度统计分析...')
    print('  --- 按天统计 ---')
    sql_daily = """
        SELECT 
            date,
            COUNT(*) as total_behavior,
            COUNT(DISTINCT user_id) as active_users,
            SUM(CASE WHEN behavior_type = 'buy' THEN 1 ELSE 0 END) as buy_count
        FROM user_behavior
        GROUP BY date
        ORDER BY date
    """
    daily_result = spark.sql(sql_daily)
    daily_result.show()

    print('  --- 按小时统计（用户活跃时段） ---')
    sql_hourly = """
        SELECT 
            hour,
            COUNT(*) as total_behavior,
            COUNT(DISTINCT user_id) as active_users,
            ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2) as percentage
        FROM user_behavior
        GROUP BY hour
        ORDER BY hour
    """
    hourly_result = spark.sql(sql_hourly)
    hourly_result.show(24)

    daily_result.toPandas().to_csv(os.path.join(OUTPUT_DIR, 'daily_statistics.csv'), index=False, encoding='utf-8')
    hourly_result.toPandas().to_csv(os.path.join(OUTPUT_DIR, 'hourly_statistics.csv'), index=False, encoding='utf-8')
    print('  时间统计结果已保存')
    return daily_result, hourly_result


def write_to_mysql(df, table_name):
    """将结果写入MySQL"""
    print(f'  写入MySQL表: {table_name}')
    df.write.jdbc(url=MYSQL_URL, table=table_name, mode='overwrite', properties=MYSQL_PROPERTIES)


def main():
    """主函数"""
    print('=' * 60)
    print('电商用户行为数据 - Spark SQL多维度统计分析')
    print('=' * 60)

    spark = create_spark_session()
    try:
        df = load_data_from_hdfs(spark, HDFS_CLEAN_PATH)
        behavior_df = analyze_behavior_distribution(spark)
        province_df = analyze_province_statistics(spark)
        category_df = analyze_category_statistics(spark)
        daily_df, hourly_df = analyze_time_statistics(spark)

        print('\n[7/7] 正在将结果写入MySQL...')
        write_to_mysql(behavior_df, 'behavior_distribution')
        write_to_mysql(province_df, 'province_statistics')
        write_to_mysql(category_df, 'category_top10')
        write_to_mysql(daily_df, 'daily_statistics')
        write_to_mysql(hourly_df, 'hourly_statistics')
        print('  所有结果已写入MySQL')
    finally:
        spark.stop()
        print('\nSparkSession已关闭')

    print('\n' + '=' * 60)
    print('Spark SQL统计分析完成！')
    print('=' * 60)
    print(f'  输出目录: {OUTPUT_DIR}')


if __name__ == '__main__':
    main()
