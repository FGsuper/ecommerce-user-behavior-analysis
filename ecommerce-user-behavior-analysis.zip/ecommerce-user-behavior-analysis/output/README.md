# 输出结果说明

本目录存放各模块运行后的输出结果。

## 文件列表

| 文件名 | 来源模块 | 说明 |
|--------|----------|------|
| behavior_distribution.csv | 02_spark_sql_analysis.py | 用户行为分布统计 |
| province_statistics.csv | 02_spark_sql_analysis.py | 31个省份维度统计 |
| category_top10.csv | 02_spark_sql_analysis.py | Top10热门商品类目 |
| daily_statistics.csv | 02_spark_sql_analysis.py | 每日用户行为统计 |
| hourly_statistics.csv | 02_spark_sql_analysis.py | 每小时用户行为统计 |
| user_recommendations.csv | 03_als_recommendation.py | 用户商品推荐结果 (Top10) |
| item_recommendations.csv | 03_als_recommendation.py | 商品用户推荐结果 (Top10) |
| model_evaluation.txt | 03_als_recommendation.py | ALS模型评估结果 (RMSE) |
| visualization_report.html | 04_visualization.py | 综合可视化报告 |
| 01_behavior_pie.html | 04_visualization.py | 用户行为分布饼图 |
| 02_behavior_bar.html | 04_visualization.py | 用户行为分布柱状图 |
| 03_province_bar.html | 04_visualization.py | 省份统计柱状图 |
| 04_hourly_line.html | 04_visualization.py | 用户活跃时段折线图 |
| 05_daily_line.html | 04_visualization.py | 每日趋势折线图 |

## 注意

- 运行各模块后会自动生成对应文件
- CSV文件使用UTF-8编码
- HTML文件可直接在浏览器中打开查看
