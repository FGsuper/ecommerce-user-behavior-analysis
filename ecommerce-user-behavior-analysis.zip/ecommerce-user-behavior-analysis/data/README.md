# 数据说明

## 数据集来源

电商用户行为数据集（UserBehavior），包含用户在电商平台上的行为记录。

## 数据字段

| 字段名 | 类型 | 说明 |
|--------|------|------|
| user_id | int | 用户ID |
| item_id | int | 商品ID |
| category_id | int | 商品类目ID |
| behavior_type | string | 行为类型：pv(浏览)、fav(收藏)、cart(加购)、buy(购买) |
| timestamp | bigint | 行为时间戳 |
| user_geohash | string | 用户地理位置（geohash编码，缺失值较多，已删除） |

## 数据规模

- 总记录数：500万+条
- 用户数：10000+
- 商品数：100万+
- 时间范围：2017年11月25日 - 2017年12月3日

## 数据预处理

1. 统计各字段缺失值与数据质量
2. 删除空白值过多的user_geohash字段
3. 新增province维度字段（从geohash解析）
4. 时间戳转换为可读日期时间格式
5. 清洗后数据上传HDFS

## 数据获取

由于数据文件较大，请自行下载并放置于本目录下：
- 文件名：UserBehavior.csv
- 下载地址：天池大赛 - 淘宝用户行为数据集
