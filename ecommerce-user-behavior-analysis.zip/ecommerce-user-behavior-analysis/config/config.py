# -*- coding: utf-8 -*-
"""
项目配置文件
"""
import os

# ==================== 路径配置 ====================
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 原始数据路径
RAW_DATA_PATH = os.path.join(BASE_DIR, 'data', 'UserBehavior.csv')
# 清洗后数据路径
CLEAN_DATA_PATH = os.path.join(BASE_DIR, 'data', 'UserBehavior_clean.csv')
# 输出路径
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')

# HDFS路径
HDFS_RAW_PATH = 'hdfs://localhost:9000/user/hadoop/ecommerce/raw/'
HDFS_CLEAN_PATH = 'hdfs://localhost:9000/user/hadoop/ecommerce/clean/'

# ==================== MySQL配置 ====================
MYSQL_HOST = 'localhost'
MYSQL_PORT = 3306
MYSQL_USER = 'root'
MYSQL_PASSWORD = '123456'
MYSQL_DATABASE = 'ecommerce_analysis'
MYSQL_URL = f'jdbc:mysql://{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DATABASE}?useSSL=false&characterEncoding=utf8'
MYSQL_PROPERTIES = {
    'user': MYSQL_USER,
    'password': MYSQL_PASSWORD,
    'driver': 'com.mysql.cj.jdbc.Driver'
}

# ==================== Spark配置 ====================
SPARK_APP_NAME = 'EcommerceUserBehaviorAnalysis'
SPARK_MASTER = 'local[*]'
SPARK_CONFIG = {
    'spark.executor.memory': '4g',
    'spark.driver.memory': '2g',
    'spark.sql.shuffle.partitions': '200',
    'spark.default.parallelism': '200',
}

# ==================== ALS模型参数 ====================
ALS_PARAMS = {
    'rank': 10,           # 隐因子维度
    'maxIter': 10,        # 最大迭代次数
    'regParam': 0.1,      # 正则化参数
    'alpha': 1.0,         # 隐式反馈参数
    'coldStartStrategy': 'drop',  # 冷启动策略
}

# 训练集/测试集划分比例
TRAIN_RATIO = 0.8
TEST_RATIO = 0.2

# 推荐数量
TOP_N_USERS = 10    # 每个用户推荐商品数
TOP_N_ITEMS = 10    # 每个商品推荐用户数
RECOMMEND_USER_COUNT = 10000  # 推荐用户数

# ==================== 数据字段配置 ====================
DATA_COLUMNS = ['user_id', 'item_id', 'category_id', 'behavior_type', 'timestamp', 'user_geohash']
BEHAVIOR_TYPES = ['pv', 'fav', 'cart', 'buy']
BEHAVIOR_NAMES = {
    'pv': '浏览',
    'fav': '收藏',
    'cart': '加购',
    'buy': '购买'
}
